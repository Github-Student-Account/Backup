<div class="{{$class}}" {!! $identifier !!}>
    {!! __($message) !!}
</div>