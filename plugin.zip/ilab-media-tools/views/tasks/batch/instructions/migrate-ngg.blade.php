<p>This tool will migrate any images you are using with NextGen Gallery.</p>
