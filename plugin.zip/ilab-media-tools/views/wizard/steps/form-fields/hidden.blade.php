<?php /** @var \MediaCloud\Plugin\Wizard\Config\Field $field */?>
<input type="hidden" name="{{$field->name()}}" value="{{$field->defaultValue()}}">
