<h1>imgix Is Setup!</h1>
<p>Everything is setup correctly and ready to go.  You may now explore other features or configure some advanced imgix options.</p>
