<h1>Let's Setup imgix!</h1>
<p>You've made a great choice.  We ❤️ imgix!</p>
<p>Before continuing, make sure that you've signed up for imgix and have created a source.  Their documentation is first class, so if you need help doing any of those things click on the <strong>imgix Documentation</strong> below.</p>
<p>Otherwise, click next to get started!</p>