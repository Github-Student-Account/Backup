<h1>Get Started With Minio</h1>
<p>Minio is a self hosted cloud storage solution that is S3 compatible.  It's a great choice for specific applications and special circumstances, but it does require you to host, install and configure the service yourself.</p>
