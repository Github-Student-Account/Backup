<h1>You are ready to use Media Cloud!</h1>
<p>Everything is setup correctly and ready to go.  You may now setup some more advanced features or configure imgix.</p>
