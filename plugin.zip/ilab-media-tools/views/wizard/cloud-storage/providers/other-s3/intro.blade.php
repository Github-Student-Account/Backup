<h1>Get Started With S3 Compatible Cloud Storage</h1>
<p>There are a variety of SAAS Cloud Storage providers that offer a service that is S3 compatible, meaning that software like Media Cloud can access it as though it were accessing Amazon S3.  These providers include Stackpath, Dreamhost and others.</p>
