<div class="video">
    {!! wp_oembed_get('https://www.youtube.com/watch?v=kjFCACrPRtU') !!}
</div>