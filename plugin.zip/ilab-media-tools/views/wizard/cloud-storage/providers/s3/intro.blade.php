<h1>Get Started With Amazon S3</h1>
<p>Amazon S3 is the premiere choice for Cloud Storage.  It combines the perfect ratio of price, performance, features and compatibility.  Of all the storage providers we support, we recommend Amazon S3 the most.</p>
<p>Before we configure Media Cloud to work with S3, please view or watch the tutorials to make sure that you've set everything up correctly on your Amazon AWS account.</p>
<p>Once you've done all of that, click on <strong>Next</strong> to configure Media Cloud.</p>
