<h1>Get Started With Google Cloud Storage</h1>
<p>Google Cloud Storage is a great performer and really the only choice if you are using other Google Cloud services such as compute or vision.</p>
<p>Before we configure Media Cloud to work with Google Cloud Storage, please read through the tutorial to make sure that you've set everything up correctly on your Google Cloud account.</p>
<p>Once you've done all of that, click on <strong>Next</strong> to configure Media Cloud.</p>
