<h1>Welcome to Media Cloud!</h1>
<p>Thanks for downloading Media Cloud!</p>
<p>Over the next few screens, we'll step through the process of getting cloud storage setup and getting the basics working.  After that you can tweak the settings to get it setup exactly as you want.</p>
